<div class="clear"></div>
        <div class="footer">
        <p>footer</p>
        </div>