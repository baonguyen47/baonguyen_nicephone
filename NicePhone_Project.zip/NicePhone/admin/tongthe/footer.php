<div class="footer">
	<h1>---- NICE PHONE <sup>@</sup> ----</h1>
 </div>