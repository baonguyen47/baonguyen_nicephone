<p class="themdanhmuc">-- THÊM DANH MỤC --</p>
<table border="1" width="50%" style="border-collapse: collapse; margin: 0 auto; ">
<form action="tongthe/danhmuc/xuly.php" method="POST">
    <tr>
        <td style="text-align: center; width: 30%;font-weight: bold;">Tên danh mục</td>
        <td ><input style="width: 98%;" type="text" name="ten_danhmuc"></td>
    </tr>
    <tr>
        <td style="text-align: center; width: 30%;font-weight: bold;">Thứ tự</td>
        <td><input style="width: 98%;" type="text" class="input" type="text" name="sothutu"></td>
    </tr>
    <tr >
        <td colspan="2" style="width: 100%;" ><input style="width: 100%;font-weight: bold;"  type="submit" name="themdanhmuc" value="Thêm danh mục"></td>
    </tr>
</form>
</table>