<ul class="admin_list">
    <li><a class="list" href="index.php?action=welcome&query=them"><i class="fa fa-home" aria-hidden="true"></i>HOME</a></li>
    <li><a class="list" href="index.php?action=quanlydanhmucsanpham&query=them">Quản lý danh mục</a></li>
    <li><a class="list" href="index.php?action=sanpham&query=them">Quản lý sản phẩm</a></li>
    <li><a class="list" href="index.php?action=qldonhang&query=lietke">Quản lý đơn hàng</a></li>
</ul>